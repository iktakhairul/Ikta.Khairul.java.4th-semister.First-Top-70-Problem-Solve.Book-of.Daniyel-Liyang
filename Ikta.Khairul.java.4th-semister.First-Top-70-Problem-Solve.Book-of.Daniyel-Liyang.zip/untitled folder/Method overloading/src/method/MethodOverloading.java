package method;

public class MethodOverloading extends Overloading {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Overloading obj =new Overloading();
		double result;
		obj.demo(10);
		obj.demo(10,20);
		obj.demo(5);
		result = obj.demo(5.5);
		System.out.println(+result);
	}

}
