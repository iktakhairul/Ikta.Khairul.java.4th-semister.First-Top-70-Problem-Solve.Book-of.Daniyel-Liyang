package Methodoverriding;

public class MethodOverriding {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Textclass obj1 = new Textclass();
		Methodoverclass obj3 = new Methodoverclass();
		Textclass obj4 = new Methodoverclass();
		
		
		obj1.methodOverRide();
		obj3.methodOverRide();
		obj4.methodOverRide();
		
	}

}
