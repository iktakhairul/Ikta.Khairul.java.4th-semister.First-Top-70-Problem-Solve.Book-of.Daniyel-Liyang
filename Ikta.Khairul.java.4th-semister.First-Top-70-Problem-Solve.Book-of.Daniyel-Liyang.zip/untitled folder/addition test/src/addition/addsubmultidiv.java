package addition;

public class addsubmultidiv {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=100,b=10,add = a+b,sub =a-b,multi=a*b,divi=a/b;
		System.out.println("the result of addition       : "+add);
		System.out.println("the result of subtraction    : " +sub);
		System.out.println("the result of multiplication : " +multi);
		System.out.println("the result of division       : " +divi);
	}

}
