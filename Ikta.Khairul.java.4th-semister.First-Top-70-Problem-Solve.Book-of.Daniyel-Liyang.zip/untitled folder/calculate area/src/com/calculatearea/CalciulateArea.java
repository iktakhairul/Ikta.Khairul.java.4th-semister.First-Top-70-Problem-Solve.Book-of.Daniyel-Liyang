package com.calculatearea;

public class CalciulateArea {

	public int area(int a, int b){
		return a*b;
	}

}
