package Methodoverriding;

public class Textclass extends MethodOverriding{

	public void methodOverRide() {
		// TODO Auto-generated method stub
		System.out.println("This is method overriding.");
	}

}
