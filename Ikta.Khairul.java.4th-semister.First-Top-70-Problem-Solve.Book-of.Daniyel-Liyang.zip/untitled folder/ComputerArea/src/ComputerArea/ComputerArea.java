package ComputerArea;

public class ComputerArea {
	public static void main(String[]args) {
		double radius;
		double area;
		radius = 20;
		area=radius*radius*3.1416;
		System.out.println("The area for the circle of radius : \n"+radius+"\n" +"is:\n"+area);
		
	} 
}
