package com.example.Test;

import java.util.Scanner;

public class Test {
	static Scanner scanner = new Scanner(System.in);
	public static void main(String[]args) {
	
		
		
		
	}
	

	static void prln(Object anyObject){
		System.out.println(anyObject);
	}
	static void pr(Object anyObject){
		System.out.print(anyObject);
	}
}
