package ComputerExpression;

import javax.naming.spi.DirStateFactory.Result;

@SuppressWarnings("unused")
public class ComputerExpression {
	public static void main(String[]args) {
		System.out.println("Result : " + (10.5+2*3)/(45-3.5));
	}

}
