package addition;

public class addition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=5,b=15,result
				;
		result = a+b;
		System.out.println("The result is : " +result);
	}
}
