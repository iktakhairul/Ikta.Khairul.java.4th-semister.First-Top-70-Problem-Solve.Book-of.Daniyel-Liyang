package salarymain;

public class programmerMain extends totalEmployee {
	int bonuS=10000;
	
	public static void main(String args[]){
		
		programmerMain abc = new programmerMain();
		
		System.out.println("Salay : "+ abc.salarY);
		System.out.println("Bonus : "+ abc.bonuS);
	}

}
