package welcome;

public class Welcome {
	public static void main(String[]args) {
		System.out.println("Welcome to java with Iktakhairul\nID  :  171-15-8606");
	}


}
