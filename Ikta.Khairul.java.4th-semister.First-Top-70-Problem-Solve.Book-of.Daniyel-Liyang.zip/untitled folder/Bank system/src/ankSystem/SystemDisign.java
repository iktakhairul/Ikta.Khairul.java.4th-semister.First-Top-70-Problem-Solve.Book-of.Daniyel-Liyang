package ankSystem;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Window.Type;
import java.awt.Dialog.ModalExclusionType;
import java.awt.Color;
import org.eclipse.wb.swing.FocusTraversalOnArray;
import java.awt.Component;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.DropMode;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.ImageIcon;
import java.awt.Scrollbar;
import java.awt.Panel;

public class SystemDisign {
	//Declare button and text field and Title
	private JFrame MainFrame;
	private JTextField textField1;
	private JButton Diposite;
	private JButton Withdraw;
	private JButton ChangePin;
	private JButton AccountInfo;
	private JButton DeleteAccount;
	private JButton ContactUs;
	private JButton AboutUs;
	private JTextField BaNkName;
	private JTextField LastTextFild;

	
	
	
	
	
	
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SystemDisign window = new SystemDisign();
					window.MainFrame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	
	
	
	
	/**
	 * Create the application.
	 */
	public SystemDisign() {
		initialize();
	}

	
	
	
	
	
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		MainFrame = new JFrame();
		MainFrame.getContentPane().setBackground(UIManager.getColor("FormattedTextField.inactiveForeground"));
		MainFrame.getContentPane().setFont(MainFrame.getContentPane().getFont().deriveFont(MainFrame.getContentPane().getFont().getSize() + 1f));
		MainFrame.setTitle("Shah Md. Iktakhairul Islam");
		MainFrame.setModalExclusionType(ModalExclusionType.TOOLKIT_EXCLUDE);
		MainFrame.setBounds(100, 100, 1400, 830);
		MainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		MainFrame.getContentPane().setLayout(null);
		
		JButton CreateAccount = new JButton("Create Account");
		CreateAccount.setIcon(null);
		CreateAccount.setForeground(new Color(128, 128, 128));
		CreateAccount.setBackground(UIManager.getColor("FormattedTextField.inactiveForeground"));
		CreateAccount.setBounds(589, 206, 181, 36);
		MainFrame.getContentPane().add(CreateAccount);
		
		Withdraw = new JButton("Withdraw Money");
		Withdraw.setForeground(Color.GRAY);
		Withdraw.setBackground(Color.GRAY);
		Withdraw.setBounds(589, 346, 181, 36);
		MainFrame.getContentPane().add(Withdraw);
		
		Diposite = new JButton("Diposite Money");
		Diposite.setForeground(Color.GRAY);
		Diposite.setBackground(Color.GRAY);
		Diposite.setBounds(589, 282, 181, 36);
		MainFrame.getContentPane().add(Diposite);
		
		textField1 = new JTextField();
		textField1.setColumns(10);
		textField1.setForeground(new Color(240, 248, 255));
		textField1.setFont(new Font("Lucida Grande", Font.BOLD, 30));
		textField1.setText("Our Available Services");
		textField1.setBackground(UIManager.getColor("FormattedTextField.inactiveForeground"));
		textField1.setBounds(226, 123, 384, 70);
		MainFrame.getContentPane().add(textField1);
		
		ChangePin = new JButton("Change PIN");
		ChangePin.setForeground(Color.GRAY);
		ChangePin.setBackground(Color.GRAY);
		ChangePin.setBounds(589, 411, 181, 36);
		MainFrame.getContentPane().add(ChangePin);
		
		AccountInfo = new JButton("Account Information");
		AccountInfo.setForeground(Color.GRAY);
		AccountInfo.setBackground(Color.GRAY);
		AccountInfo.setBounds(589, 543, 181, 36);
		MainFrame.getContentPane().add(AccountInfo);
		
		DeleteAccount = new JButton("Delete Account");
		DeleteAccount.setForeground(Color.GRAY);
		DeleteAccount.setBackground(Color.GRAY);
		DeleteAccount.setBounds(589, 477, 181, 36);
		MainFrame.getContentPane().add(DeleteAccount);
		
		ContactUs = new JButton("Contact Us");
		ContactUs.setForeground(Color.GRAY);
		ContactUs.setBackground(Color.GRAY);
		ContactUs.setBounds(589, 607, 181, 36);
		MainFrame.getContentPane().add(ContactUs);
		
		AboutUs = new JButton("About Us");
		AboutUs.setForeground(Color.GRAY);
		AboutUs.setBackground(Color.GRAY);
		AboutUs.setBounds(589, 671, 181, 36);
		MainFrame.getContentPane().add(AboutUs);
		
		BaNkName = new JTextField();
		BaNkName.setHorizontalAlignment(SwingConstants.CENTER);
		BaNkName.setFont(new Font("Lucida Grande", Font.BOLD, 45));
		BaNkName.setForeground(new Color(248, 248, 255));
		BaNkName.setText("Bangladesh Central Bank");
		BaNkName.setBackground(UIManager.getColor("FormattedTextField.inactiveForeground"));
		BaNkName.setBounds(257, 6, 821, 105);
		MainFrame.getContentPane().add(BaNkName);
		BaNkName.setColumns(10);
		
		LastTextFild = new JTextField();
		LastTextFild.setForeground(new Color(220, 220, 220));
		LastTextFild.setHorizontalAlignment(SwingConstants.CENTER);
		LastTextFild.setText(" https://github.com/Iktakhairul");
		LastTextFild.setBackground(UIManager.getColor("FormattedTextField.inactiveForeground"));
		LastTextFild.setBounds(490, 774, 413, 26);
		MainFrame.getContentPane().add(LastTextFild);
		LastTextFild.setColumns(10);
		
		Scrollbar scrollbar = new Scrollbar();
		scrollbar.setValueIsAdjusting(true);
		scrollbar.setForeground(new Color(0, 0, 0));
		scrollbar.setBounds(1377, 0, 23, 800);
		MainFrame.getContentPane().add(scrollbar);
		MainFrame.setFocusTraversalPolicy(new FocusTraversalOnArray(new Component[]{MainFrame.getContentPane()}));
	}

	public Color getFrameContentPaneBackground() {
		return MainFrame.getContentPane().getBackground();
	}
	public void setFrameContentPaneBackground(Color background) {
		MainFrame.getContentPane().setBackground(background);
	}
}
