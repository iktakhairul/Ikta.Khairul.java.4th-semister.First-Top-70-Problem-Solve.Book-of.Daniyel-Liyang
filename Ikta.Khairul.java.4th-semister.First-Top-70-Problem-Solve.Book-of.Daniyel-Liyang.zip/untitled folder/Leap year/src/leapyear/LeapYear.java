package leapyear;

import java.util.Scanner;

public class LeapYear {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		do{
		@SuppressWarnings("resource")
		Scanner input=new Scanner(System.in);
		System.out.println("Enter  a year : ");
		int year=input.nextInt();
		boolean isLearYear = ( year % 4 ==0 && year % 100 !=0) || (year % 400 == 0);
		System.out.println(year + " is a Leap Year ? :" + isLearYear );
		if (isLearYear==false) {
			System.out.println(year +" is not Leap Year"+"\n");
		}else
			System.out.println(year +" is Leap Year" +"\n");	
		}
		while(true);
		
	}

}
