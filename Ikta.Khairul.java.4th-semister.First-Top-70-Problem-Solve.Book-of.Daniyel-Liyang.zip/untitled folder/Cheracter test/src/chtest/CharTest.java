package chtest;

public class CharTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char x = 'a';
		char y = 'c';
		System.out.println(++x);
		System.out.println(y++);
		System.out.println(x - y);
	}

}
