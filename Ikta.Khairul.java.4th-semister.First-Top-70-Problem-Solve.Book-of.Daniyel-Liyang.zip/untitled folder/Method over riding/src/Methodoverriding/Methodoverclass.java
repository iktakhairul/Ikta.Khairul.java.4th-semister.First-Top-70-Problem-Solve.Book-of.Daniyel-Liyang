package Methodoverriding;

public class Methodoverclass extends Textclass {
	public void methodOverRide(){
		System.out.println("I am the method");
	}

}
