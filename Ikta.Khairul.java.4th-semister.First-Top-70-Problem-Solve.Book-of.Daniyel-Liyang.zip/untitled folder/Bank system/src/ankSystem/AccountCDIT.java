package ankSystem;
import java.util.Scanner;

public class AccountCDIT {
	Scanner input = new Scanner(System.in);
	//Declare variable********

	
	String tempName,tempAddress,tempPhoneNumber,tempBankPIN;
	
	
//Here we Create Account and Password. Account information also------ Account Create() && Account Information ()
	//first create a constructor
	public AccountCDIT(String name,String address, String phonenumber , int pin){
		name = "name";
		address = "Address";
		phonenumber = "01683201359";
		pin = 12345 ;
		
	}
	
	///now create account by constructor
	public void AccountCreate(){
		System.out.println("Give us your all Information bellow :- ");
		System.out.print(" Your Name--------------------:- ");
		
		
		
		/**
		System.out.println("Give us your all Information bellow :- ");
		
		System.out.print(" Your Name--------------------:- ");
		String tempName = input.nextLine();
		//System.out.print(tempName+"\n");
		
		
		System.out.print(" Your Address-----------------:- ");
		String tempAddress   = input.nextLine();
		//System.out.print(tempAddress+"\n");
		
		
		System.out.print(" Your Phone Number------------:- ");
		tempPhoneNumber   = input.nextLine();
		//System.out.print(tempPhoneNumber+"\n");
		
		
		System.out.print(" Enter a 4 Disit PIN Number---:- ");
		tempBankPIN = input.next();
		
		int accountNumber = (int)(Math.random()*10);
		System.out.print("your bank account number : "+accountNumber);
		
		
		
		
		return (tempBankPIN +","+ tempAddress+"," +tempName + "," +tempPhoneNumber);
		*/
	
	}//End entry AccountCreation info name,address,phone number,pin 

}//end class
