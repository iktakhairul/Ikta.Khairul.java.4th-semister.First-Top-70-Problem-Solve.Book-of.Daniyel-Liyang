package salarymain;

public class totalEmployee {
	int salarY = 20000;
}
