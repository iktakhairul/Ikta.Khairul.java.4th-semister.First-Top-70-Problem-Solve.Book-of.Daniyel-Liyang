package javaout;

public class OutputTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("1" + 1);
		System.out.println('1' +  1);
		System.out.println("1" + 1 + 1);
		System.out.println("1" +(1 + 1));
		System.out.println('1' + 1 + 1);
	}

}
