package ankSystem;
import java.util.Scanner;
public class BankMain {


	//public static void main(String[] args) {
		// TODO Auto-generated method stub
	public void BankLuncing(){
		//bank name*
		System.out.println("------------------------------Iktakhairul bank------------------------------\n\n");
		
		//Declare variable**********************?//Declare variable********
		
		
		
		//we want do while for not exiting by program
		do{ 
			//operation user control by print information
			
		System.out.print("\n\n\n Our Available Services Bellow :-"
				+ "\n1. Deposit Money.\n"
				+ "2. Widraw Money.   \n"
				+ "3. Create Account.\n"//done by AccountCreate()
				+ "4. Delete Account. \n"
				+ "5. Change PIN. \n"
				+ "6. Account Information.     \n"
				+ "7. Totall Entire Bank Balance. \n"
				+ "8. Contact Us.     \n"
				+ "9. About Us.       \n"
				+ " What Operation Do You Want ? sir please enter --:-" + ")" );
		
		//input**
		@SuppressWarnings("resource")
		Scanner input = new Scanner(System.in);
		int option = input.nextInt();
		
		//create object for operation*****
		//AccountCDIT objAccountCDIT = new AccountCDIT();
		
		
		
		
		//create switch  for operation for Input by user.***
		switch (option) {
		
		
		case 1 : System.out.println("\n * ----- Diposite ----- * ");
			//objAccountCDIT.AccounDeposit(accountNumber);
		
		
			break;
			
			
			
		case 2 : System.out.println("\n ----- Widraw ----- * ");
		break;
		
		
			
		case 3 : System.out.println("\n * ----- Sign up ----- * ");
				///objAccountCDIT.AccountCreate();
			break;
			
			
		case 4 : System.out.println("\n * ----- Delete Account ----- ");
			
		
			break;
			
			
			
		case 5 : System.out.println("\n * ----- Change PIN ----- * ");
			break;
			
			
		case 6: System.out.println("\n * ----- Account Information ----- * ");
		//objAccountCDIT.AccountInfo();
		break;
			
			
			
			
		case 7 : System.out.println("\n * ----- Entire Bank Balance  ----- * ");
			break;
			
			

		case 8 : System.out.println("\n * ----- Contact Us ----- * ");
			break;
			
			

		case 9: System.out.println("\n * ----- About Us ----- * ");
			break;
		
			
			
			
			
		default: System.out.println("\n    *    Invalid Input!!!, please enter desimal valid value.    *    ");
			break;
		}
	
		
		
		
		
		
		
		}while(true);//end do while loop
		
	}

}
