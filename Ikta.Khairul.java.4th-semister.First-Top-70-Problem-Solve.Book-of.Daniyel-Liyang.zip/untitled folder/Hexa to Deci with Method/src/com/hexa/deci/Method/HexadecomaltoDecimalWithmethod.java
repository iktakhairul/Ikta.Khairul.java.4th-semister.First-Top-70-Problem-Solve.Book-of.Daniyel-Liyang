package com.hexa.deci.Method;

import java.util.Scanner;

public class HexadecomaltoDecimalWithmethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		do{
		System.out.print("Enter a Hexadecimal number : ");
		@SuppressWarnings("resource")
		Scanner input = new Scanner(System.in);
		String hex = input.nextLine();
		System.out.print("The Decimal value of Hexadecimal '"+ hex +"' is : "+ hextoDecimal(hex.toUpperCase())+"\n");
		}while(true);
	}
	
	
	
	public static int hextoDecimal(String hex){
		
		int decimalValue = 0;
		for (int i =0 ;i< hex.length(); i++){
			char hexchar = hex.charAt(i);
			decimalValue = decimalValue * 16 + hexchartoDecimal(hexchar);
			
			
		}
		
		
		return decimalValue;
	}
	
	
	public static int hexchartoDecimal(char ch){
		if (ch >= 'A' && ch <= 'F') {
			return 10 + ch -'A';
		}else
			return ch - '0';
	}

}
